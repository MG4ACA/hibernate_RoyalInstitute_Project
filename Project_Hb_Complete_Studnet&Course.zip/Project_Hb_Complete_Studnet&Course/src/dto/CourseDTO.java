package dto;

public class CourseDTO implements SuperDTO{
    private String code;
    private String courseName;
    private String duration;
    private String courseFee;


    public CourseDTO() {
    }

    public CourseDTO(String code, String courseName, String duration, String courseFee) {
        this.code = code;
        this.courseName = courseName;
        this.duration = duration;
        this.courseFee = courseFee;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseFee() {
        return courseFee;
    }

    public void setCourseFee(String courseFee) {
        this.courseFee = courseFee;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "CourseDTO{" +
                "code='" + code + '\'' +
                ", courseName='" + courseName + '\'' +
                ", duration='" + duration + '\'' +
                ", courseFee='" + courseFee + '\'' +
                '}';
    }
}
