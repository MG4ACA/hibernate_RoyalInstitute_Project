package business.custom.impl;

import business.custom.RegistrationBO;
import dao.DAOFactory;
import dao.DAOType;
import dao.custom.RegistrationDAO;
import dto.RegistrationDTO;
import entity.Registration;

import java.util.ArrayList;
import java.util.List;

public class RegistrationBOImpl implements RegistrationBO {
    RegistrationDAO registrationDAO =DAOFactory.getInstance().getDAO(DAOType.REGISTRATION);

    @Override
    public boolean addRegistration(RegistrationDTO registration) throws Exception {
        return registrationDAO.add(new Registration(registration.getRegNo(),registration.getRegDate(),
                registration.getRegFee(),registration.getStudent(),registration.getCourse()));
    }

    @Override
    public boolean deleteRegistration(RegistrationDTO registration) throws Exception {
        return registrationDAO.add(new Registration(registration.getRegNo(),registration.getRegDate(),
                registration.getRegFee(),registration.getStudent(),registration.getCourse()));
    }

    @Override
    public boolean updateRegistration(RegistrationDTO registration) throws Exception {
        return registrationDAO.add(new Registration(registration.getRegNo(),registration.getRegDate(),
                registration.getRegFee(),registration.getStudent(),registration.getCourse()));
    }

    @Override
    public RegistrationDTO getRegistration(String id) throws Exception {
        Registration registration = registrationDAO.getOne(id);
        return new RegistrationDTO(registration.getRegNo(),registration.getRegDate(),
                registration.getRegFee(),registration.getStudent(),registration.getCourse());
    }

    @Override
    public List<RegistrationDTO> getAllRegistration() throws Exception {
        List<Registration> registrationList = registrationDAO.getAll();
        List<RegistrationDTO> registrationDTOList=new ArrayList<>();
        for ( Registration registration:registrationList) {
            registrationDTOList.add(new RegistrationDTO(registration.getRegNo(),registration.getRegDate(),
                    registration.getRegFee(),registration.getStudent(),registration.getCourse()));
        }
        return registrationDTOList;
    }
}
