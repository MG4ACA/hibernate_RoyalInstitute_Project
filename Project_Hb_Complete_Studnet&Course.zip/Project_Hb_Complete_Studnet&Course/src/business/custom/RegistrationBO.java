package business.custom;

import business.SuperBO;
import dto.RegistrationDTO;

import java.util.List;

public interface RegistrationBO extends SuperBO {
    public boolean addRegistration(RegistrationDTO registration)throws Exception;

    public boolean deleteRegistration(RegistrationDTO registration)throws Exception;

    public boolean updateRegistration(RegistrationDTO registration)throws Exception;

    public RegistrationDTO getRegistration(String id)throws Exception;

    public List<RegistrationDTO> getAllRegistration()throws Exception;
}
