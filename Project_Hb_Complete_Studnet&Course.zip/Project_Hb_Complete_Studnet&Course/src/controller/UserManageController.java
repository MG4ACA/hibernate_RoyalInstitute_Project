package controller;

import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class UserManageController {
    public JFXTextField txtUserName;
    public Label lblPassword;
    public Label lblUserName;
    public JFXTextField txtPassword;
    public Button btnUpdate;

    public void updateOnAction(ActionEvent actionEvent) {
    }
}
