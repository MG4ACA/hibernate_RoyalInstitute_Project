package controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;


public class RegistrationFormController {
    public JFXTextField txt_regNo;
    public JFXTextField txt_CourseCode;
    public JFXTextField txt_RegFee;
    public JFXTextField txt_StudentId;
    public JFXDatePicker dp_regDate;
    public JFXButton btnRegister;

    public void registerOnAction(ActionEvent actionEvent) {


    }

    public void searchOnAction(ActionEvent actionEvent) {
    }

    public void UpdateOnAction(ActionEvent actionEvent) {
    }

    public void deleteOnAction(ActionEvent actionEvent) {
    }
}
