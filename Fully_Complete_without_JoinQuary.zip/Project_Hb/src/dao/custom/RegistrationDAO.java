package dao.custom;

import dao.SuperDAO;
import entity.Registration;

public interface RegistrationDAO extends SuperDAO<Registration,String> {
}
