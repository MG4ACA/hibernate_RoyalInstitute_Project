package business;

public enum BOType {
    STUDENT,COURSE,REGISTRATION,USER;
}
