package business.custom.impl;

import business.custom.CourseBO;
import dao.DAOFactory;
import dao.DAOType;
import dao.custom.CourseDAO;
import dto.CourseDTO;
import entity.Course;

import java.util.ArrayList;
import java.util.List;

public class CourseBOImpl implements CourseBO {
    CourseDAO courseDAO=DAOFactory.getInstance().getDAO(DAOType.COURSE);

    @Override
    public boolean addCourse(CourseDTO course) throws Exception {
        return courseDAO.add(new Course(course.getCode(),course.getCourseName(), course.getDuration(), course.getCourseFee()));
    }

    @Override
    public boolean deleteCourse(CourseDTO course) throws Exception {
        return courseDAO.delete(new Course(course.getCode(),course.getCourseName(), course.getDuration(), course.getCourseFee()));
    }

    @Override
    public boolean updateCourse(CourseDTO course) throws Exception {
        return courseDAO.update(new Course(course.getCode(),course.getCourseName(), course.getDuration(), course.getCourseFee()));
    }

    @Override
    public CourseDTO getCourse(String id) throws Exception {
        Course course = courseDAO.getOne(id);
        return new CourseDTO(course.getCode(),course.getCourseName(), course.getDuration(), course.getCourseFee());
    }

    @Override
    public List<CourseDTO> getAllCourses() throws Exception {
        List<Course> courseList= courseDAO.getAll();
        List<CourseDTO> courseDTOList=new ArrayList<>();
        for ( Course course: courseList ) {
            courseDTOList.add(new CourseDTO(course.getCode(),course.getCourseName(), course.getDuration(), course.getCourseFee()));
        }
        return courseDTOList;
    }
}
