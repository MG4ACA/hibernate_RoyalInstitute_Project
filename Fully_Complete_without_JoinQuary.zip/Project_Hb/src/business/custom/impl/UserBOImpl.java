/*
package business.custom.impl;

import business.custom.UserBO;
import dao.DAOFactory;
import dao.DAOType;
import dao.custom.UserDAO;
import dto.StudentDTO;
import dto.UserDTO;
import entity.User;

import java.util.ArrayList;
import java.util.List;

public class  UserBOImpl implements UserBO {
    UserDAO userDAO= DAOFactory.getInstance().getDAO(DAOType.USER);

    @Override
    public boolean updateUser(UserDTO user) throws Exception {
        return userDAO.update(new User(user.getId(), user.getUsername(), user.getPassword()));
    }

    @Override
    public UserDTO getUser(String id) throws Exception {
        User one = userDAO.getOne(id);
        return new UserDTO(one.getId(), one.getUsername(), one.getPassword());
    }

    @Override
    public List<UserDTO> getAllUsers() throws Exception {
        List<User> userList = userDAO.getAll();
        List<UserDTO> userDTOList = new ArrayList<>();
        for (User user : userList) {
            userDTOList.add(new UserDTO(user.getId(), user.getUsername(), user.getPassword()));
        }
        return userDTOList;
    }

}
*/
