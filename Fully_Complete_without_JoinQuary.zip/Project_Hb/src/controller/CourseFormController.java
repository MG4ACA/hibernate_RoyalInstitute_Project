package controller;

import business.BOFactory;
import business.BOType;
import business.custom.CourseBO;
import com.jfoenix.controls.JFXTextField;
import dto.CourseDTO;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Paint;
import model.CourseTM;
import model.StudentTM;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

public class CourseFormController {

    public JFXTextField txt_CourseCode;
    public JFXTextField txt_Duration;
    public JFXTextField txt_CourseName;
    public JFXTextField txt_CourseFee;
    public TableColumn clmProgramID;
    public TableColumn clmName;
    public TableColumn clmFee;
    public TableColumn clmDuration;
    public TableView tblCourse;


    CourseBO courseBO= BOFactory.getInstance().getBO(BOType.COURSE);

    public void initialize() {
        clmProgramID.setCellValueFactory(new PropertyValueFactory<>("code"));
        clmName.setCellValueFactory (new PropertyValueFactory<> ("courseName"));
        clmDuration.setCellValueFactory(new PropertyValueFactory<> ("duration"));
        clmFee.setCellValueFactory(new PropertyValueFactory<> ("courseFee"));
        try {
            loadTable ();
        } catch (Exception e) {
            e.printStackTrace();
        }
        tblCourse.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            setData((CourseTM) newValue);
        });
    }

    public void loadTable() {
        ObservableList<CourseTM> items = tblCourse.getItems();
        items.clear();
        try {
            List<CourseDTO> allCourses = courseBO.getAllCourses();
            for (CourseDTO course : allCourses ) {
                items.add(new CourseTM(course.getCode(), course.getCourseName()
                        , course.getDuration(), course.getCourseFee()));
            }
            tblCourse.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addCourseOnAction(ActionEvent actionEvent) {
        CourseDTO courseDTO = new CourseDTO(txt_CourseCode.getText(), txt_CourseName.getText(), txt_CourseFee.getText(), txt_Duration.getText());

        if (Pattern.compile("^(CT0)[0-9]{3}$").matcher(txt_CourseCode.getText()).matches()) {
           // if (Pattern.compile("^[A-z]{1,100} [A-z]{1,100}$").matcher(txt_CourseName.getText()).matches()) {
            if (Pattern.compile("^[0-9]{1,2} [a-z]{1,10}$").matcher(txt_Duration.getText()).matches()) {
            if (Pattern.compile("^[0-9]{1,3},[0-9]{3}.[0-9]{2}$").matcher(txt_CourseFee.getText()).matches()) {
                        try {
                            boolean isAdded = courseBO.addCourse(new CourseDTO(txt_CourseCode.getText(), txt_CourseName.getText(), txt_Duration.getText(), txt_CourseFee.getText()));
                            if (isAdded) {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Course Saved Successfully");
                                alert.show();
                                clear();
                                loadTable();
                            } else {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Course Not Saved");
                                alert.show();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            Alert alert = new Alert(Alert.AlertType.WARNING, "Duplicate Course ID");
                            alert.show();
                        }
                } else {
                    txt_CourseFee.setFocusColor(Paint.valueOf("red"));
                    txt_CourseFee.requestFocus();
                }
            } else {
                txt_Duration.setFocusColor(Paint.valueOf("red"));
                txt_Duration.requestFocus();
            }
         /*   } else {
                txt_CourseName.setFocusColor(Paint.valueOf("red"));
                txt_CourseName.requestFocus();
            }*/
        } else {
            txt_CourseCode.setFocusColor(Paint.valueOf("red"));
            txt_CourseCode.requestFocus();
        }
    }

    public void deleteOnAction(ActionEvent actionEvent) {
        try {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Are sure ..?", ButtonType.YES, ButtonType.NO);
            Optional<ButtonType> buttonType = alert.showAndWait();

            if (buttonType.get().equals(ButtonType.YES)) {
                courseBO.deleteCourse(new CourseDTO(txt_CourseCode.getText(),txt_CourseName.getText(), txt_CourseFee.getText(),txt_Duration.getText()));
                loadTable();
                clear();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void UpdateOnAction(ActionEvent actionEvent) {
        if (Pattern.compile("^(CT0)[0-9]{3}$").matcher(txt_CourseCode.getText()).matches()) {
            //if (Pattern.compile("^[A-z]{1,100} [A-z]{1,100}$").matcher(txt_CourseName.getText()).matches()) {
            if (Pattern.compile("^[0-9]{1,2} [a-z]{1,10}$").matcher(txt_Duration.getText()).matches()) {
                if (Pattern.compile("^[0-9]{1,3},[0-9]{3}.[0-9]{2}$").matcher(txt_CourseFee.getText()).matches()) {
                        try {
                             boolean isUpdated = courseBO.updateCourse(new CourseDTO(txt_CourseCode.getText(), txt_CourseName.getText(), txt_Duration.getText(), txt_CourseFee.getText()));
                            if (isUpdated) {
                                new Alert(Alert.AlertType.INFORMATION, "Updated Successfully").show();
                                clear();
                                loadTable();
                            } else {
                                new Alert(Alert.AlertType.INFORMATION, "Updated Fail !").show();
                            }
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                    } else {
                        txt_CourseFee.setFocusColor(Paint.valueOf("red"));
                        txt_CourseFee.requestFocus();
                    }
                    } else {
                        txt_Duration.setFocusColor(Paint.valueOf("red"));
                        txt_Duration.requestFocus();
                    }
            /*} else {
                txt_CourseName.setFocusColor(Paint.valueOf("red"));
                txt_CourseName.requestFocus();
            }*/
        } else {
            txt_CourseCode.setFocusColor(Paint.valueOf("red"));
            txt_CourseCode.requestFocus();
        }
    }

    public void searchOnAction(ActionEvent actionEvent) {
        try{
            CourseDTO course = courseBO.getCourse(txt_CourseCode.getText());
            if (null != course) {
                txt_CourseCode .setText(course.getCode());
                txt_CourseName.setText(course.getCourseName());
                txt_Duration.setText(course.getDuration());
                txt_CourseFee.setText(course.getCourseFee());
            } else {
                new Alert(Alert.AlertType.WARNING, "Search Does not Match").show();
            }
        }catch(Exception e){
            //  e.printStackTrace();
            new Alert(Alert.AlertType.WARNING,"Search Does not Match" ).show();
        }
    }

    private void clear(){
        txt_CourseCode.clear();
        txt_CourseName.clear();
        txt_CourseFee.clear();
        txt_Duration.clear();
    }

    private void setData(CourseTM tm) {
        txt_CourseCode.setText (tm.getCode ());
        txt_CourseName.setText (tm.getCourseName ());
        txt_Duration.setText (tm.getDuration ());
        txt_CourseFee.setText (tm.getCourseFee ());
    }
}
