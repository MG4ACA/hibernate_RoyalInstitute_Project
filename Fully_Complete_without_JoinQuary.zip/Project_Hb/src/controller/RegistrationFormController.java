package controller;

import business.BOFactory;
import business.BOType;
import business.custom.CourseBO;
import business.custom.RegistrationBO;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import dto.CourseDTO;
import dto.RegistrationDTO;
import dto.StudentDTO;
import entity.Course;
import entity.Student;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Paint;
import model.RegistrationTM;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;


public class RegistrationFormController {
    public JFXTextField txt_regNo;
    public JFXTextField txt_RegFee;
    public JFXTextField txt_StudentId;
    public JFXDatePicker dp_regDate;
    public JFXButton btnRegister;
    public TableColumn clmRegNum;
    public TableColumn clmDate;
    public TableColumn clmFee;
    public TableColumn clmSId;
    public TableColumn clmCCode;
    public TableView tblRegistration;
    public JFXComboBox<String> cmb_CourseCode;

    RegistrationBO registrationBO= BOFactory.getInstance().getBO(BOType.REGISTRATION);
    CourseBO courseBO= BOFactory.getInstance().getBO(BOType.COURSE);
    Student student = new Student();
    Course course = new Course();
    public void initialize() {
        cmb_CourseCode.getSelectionModel ().clearSelection ();
        try{
            List<CourseDTO> item = courseBO.getAllCourses ();
            for (CourseDTO course : item) {
                cmb_CourseCode.getItems().addAll(course.getCode ());
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        clmRegNum.setCellValueFactory(new PropertyValueFactory<>("regNo"));
        clmDate.setCellValueFactory (new PropertyValueFactory<> ("regDate"));
        clmFee.setCellValueFactory(new PropertyValueFactory<> ("regFee"));
        clmSId.setCellValueFactory(new PropertyValueFactory<> ("student"));
        clmCCode.setCellValueFactory(new PropertyValueFactory<> ("course"));
        try {
            loadTable ();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadTable() {
        ObservableList<RegistrationTM> items = tblRegistration.getItems();
        items.clear();
        try {
            List<RegistrationDTO> allRegistration = registrationBO.getAllRegistration();
            for (RegistrationDTO registration : allRegistration ) {
                items.add(new RegistrationTM(registration.getRegNo(), registration.getRegDate()
                        ,registration.getRegFee(), registration.getStudent().getId (),registration.getCourse().getCode ()));
            }
            tblRegistration.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void registerOnAction(ActionEvent actionEvent) {
        if (Pattern.compile("^(R0)[0-9]{2}$").matcher(txt_regNo.getText()).matches()) {
                if (Pattern.compile("^[0-9]{1,3}[0-9]{3}.[0-9]{2}$").matcher(txt_RegFee.getText()).matches()) {
                    try {
                        student.setId(txt_StudentId.getText());
                        course.setCode(cmb_CourseCode.getValue());
                        boolean isAdded = registrationBO.addRegistration(new RegistrationDTO(txt_regNo.getText(), dp_regDate.getValue().toString(), Double.parseDouble(txt_RegFee.getText()), student,course));
                        System.out.println(new RegistrationDTO(txt_regNo.getText(), dp_regDate.getValue().toString(), Double.parseDouble(txt_RegFee.getText()), student,course));
                        if (isAdded) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Student Registered Successfully");
                            alert.show();
                            clear();
                            loadTable();
                        } else {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Student not Registered");
                            alert.show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Alert alert = new Alert(Alert.AlertType.WARNING,e.toString());
                        alert.show();
                    }
                } else {
                    txt_RegFee.setFocusColor(Paint.valueOf("red"));
                    txt_RegFee.requestFocus();
                }
        } else {
            txt_regNo.setFocusColor(Paint.valueOf("red"));
            txt_regNo.requestFocus();
        }
    }

    private void clear() {
        txt_regNo.clear();
        txt_RegFee.clear();
        txt_StudentId.clear();
        cmb_CourseCode.getSelectionModel ().clearSelection ();
        dp_regDate.getEditor().clear();
    }

    public void searchOnAction(ActionEvent actionEvent) {
        try{
            RegistrationDTO registration = registrationBO.getRegistration(txt_regNo.getText());
            if (null != registration) {
                txt_RegFee .setText(String.valueOf(registration.getRegFee()));
                txt_StudentId.setText(registration.getStudent().getId());
                dp_regDate.setValue (LocalDate.parse (registration.getRegDate ()));
                cmb_CourseCode.setValue(registration.getCourse().getCode());
                txt_StudentId.setText(registration.getStudent ().getId ());
            } else {
                new Alert(Alert.AlertType.WARNING, "Search Does not Match").show();
            }
        }catch(Exception e){
            //  e.printStackTrace();
            new Alert(Alert.AlertType.WARNING,"Search Does not Match" ).show();
        }
    }

    public void UpdateOnAction(ActionEvent actionEvent) {
        if (Pattern.compile("^(R0)[0-9]{2}$").matcher(txt_regNo.getText()).matches()) {
            if (Pattern.compile("^[0-9]{1,3}[0-9]{3}.[0-9]{2}$").matcher(txt_RegFee.getText()).matches()) {
                boolean isUpdated = false;
                try{
                    student.setId(txt_StudentId.getText());
                    course.setCode(cmb_CourseCode.getValue());
                    isUpdated = registrationBO.updateRegistration (new RegistrationDTO(txt_regNo.getText(), dp_regDate.getValue().toString(), Double.parseDouble(txt_RegFee.getText()), student,course));
                    if (isUpdated) {
                        new Alert(Alert.AlertType.INFORMATION, "Updated Successfully").show();
                        clear();
                        loadTable();
                    } else {
                        new Alert(Alert.AlertType.INFORMATION, "Updated Fail !").show();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }

            } else {
                txt_RegFee.setFocusColor(Paint.valueOf("red"));
                txt_RegFee.requestFocus();
            }
        } else {
            txt_regNo.setFocusColor(Paint.valueOf("red"));
            txt_regNo.requestFocus();
        }
    }

    public void deleteOnAction(ActionEvent actionEvent) {
        try {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Are sure ..?", ButtonType.YES, ButtonType.NO);
            Optional<ButtonType> buttonType = alert.showAndWait();
            if (buttonType.get().equals(ButtonType.YES)) {
                student.setId(txt_StudentId.getText());
                course.setCode(cmb_CourseCode.getValue());
                registrationBO.deleteRegistration(new RegistrationDTO(txt_regNo.getText(),dp_regDate.getValue().toString (), Double.parseDouble (txt_RegFee.getText()),student,course));
                loadTable();
                clear();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
