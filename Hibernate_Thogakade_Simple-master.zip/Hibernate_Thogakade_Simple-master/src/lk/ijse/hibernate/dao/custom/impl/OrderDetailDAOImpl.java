package lk.ijse.hibernate.dao.custom.impl;

import lk.ijse.hibernate.dao.custom.OrderDetailDAO;
import lk.ijse.hibernate.entity.Item;
import lk.ijse.hibernate.entity.OrderDetail;
import lk.ijse.hibernate.util.FactoryConfiguration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.io.Serializable;
import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/24/21
 **/

public class OrderDetailDAOImpl implements OrderDetailDAO {
    @Override
    public boolean add(OrderDetail entity) throws Exception {
        Session session = FactoryConfiguration.getInstance().getSession();

        Transaction transaction = session.beginTransaction();

        Item itemCode = entity.getItemCode();

        Item item = session.get(Item.class, itemCode.getId());

        int item_qty = Integer.parseInt(item.getQty());
        int new_qty = Integer.parseInt(entity.getQty().getQty());

        int updated_qty = item_qty - new_qty;

        item.setQty(updated_qty+"");

        session.update(item);

        Serializable save = session.save(entity);

        transaction.commit();

        session.close();

        if((Integer.parseInt(save.toString())) != 0 ){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean delete(OrderDetail entity) throws Exception {
        Session session = FactoryConfiguration.getInstance().getSession();

        Transaction transaction = session.beginTransaction();

        session.delete(entity);

        transaction.commit();
        session.close();
        return true;
    }

    @Override
    public boolean update(OrderDetail entity) throws Exception {
        Session session = FactoryConfiguration.getInstance().getSession();

        Transaction transaction = session.beginTransaction();

        session.update(entity);

        transaction.commit();

        session.close();

        return true;
    }

    @Override
    public List<OrderDetail> getAll() throws Exception {
        Session session = FactoryConfiguration.getInstance().getSession();

        Transaction transaction = session.beginTransaction();

        Query from_orderDetail_ = session.createQuery("from OrderDetail ");

        List<OrderDetail> list = from_orderDetail_.list();

        transaction.commit();
        session.close();
        return list;
    }

    @Override
    public OrderDetail getOne(String s) throws Exception {
        Session session = FactoryConfiguration.getInstance().getSession();

        Transaction transaction = session.beginTransaction();

        OrderDetail orderDetail = session.get(OrderDetail.class, s);

        transaction.commit();

        session.close();

        return orderDetail;
    }
}
