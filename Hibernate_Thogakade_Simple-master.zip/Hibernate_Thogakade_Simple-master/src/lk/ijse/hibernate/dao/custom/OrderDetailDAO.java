package lk.ijse.hibernate.dao.custom;

import lk.ijse.hibernate.dao.SuperDAO;
import lk.ijse.hibernate.entity.OrderDetail;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/24/21
 **/

public interface OrderDetailDAO extends SuperDAO<OrderDetail,String> {
}
