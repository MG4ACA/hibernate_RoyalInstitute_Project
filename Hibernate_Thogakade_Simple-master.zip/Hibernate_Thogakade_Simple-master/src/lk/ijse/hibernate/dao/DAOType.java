package lk.ijse.hibernate.dao;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/24/21
 **/

public enum DAOType {
    CUSTOMER,ITEM,ORDER,ORDER_DETAIL
}
