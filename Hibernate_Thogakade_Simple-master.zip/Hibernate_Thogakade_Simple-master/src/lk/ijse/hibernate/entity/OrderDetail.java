package lk.ijse.hibernate.entity;

import javax.persistence.*;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/24/21
 **/

@Entity
public class OrderDetail implements SuperEntity {
    @Id
    private String id;
    @ManyToOne
    @JoinColumn(name = "itemCode" , referencedColumnName = "id")
    private Item itemCode;
    @ManyToOne
    @JoinColumn(referencedColumnName = "qty")
    private Item qty;
    @ManyToOne
    @JoinColumn(name = "orderId" , referencedColumnName = "id")
    private Order order;

    public OrderDetail(String id, Item itemCode, Item qty, Order order) {
        this.id = id;
        this.itemCode = itemCode;
        this.qty = qty;
        this.order = order;
    }

    public OrderDetail() {
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Item getItemCode() {
        return itemCode;
    }

    public void setItemCode(Item itemCode) {
        this.itemCode = itemCode;
    }

    public Item getQty() {
        return qty;
    }

    public void setQty(Item qty) {
        this.qty = qty;
    }

    @Override
    public String toString() {
        return "OrderDetail{" +
                "id='" + id + '\'' +
                ", itemCode=" + itemCode +
                ", qty=" + qty +
                '}';
    }
}
