package lk.ijse.hibernate.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.ijse.hibernate.business.BOFactory;
import lk.ijse.hibernate.business.BOType;
import lk.ijse.hibernate.business.custom.CustomerBO;
import lk.ijse.hibernate.dto.CustomerDTO;
import lk.ijse.hibernate.model.CustomerTM;

import java.util.List;
import java.util.Optional;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class CustomerController {
    public JFXTextField txtID;
    public JFXTextField txtName;
    public JFXTextField txtAddress;
    public JFXButton btnSave;
    public JFXButton btnDelete;
    public TableView<CustomerTM> tblCustomers;
    public JFXButton btnBack;

    CustomerBO customerBO = BOFactory.getInstance().getBO(BOType.CUSTOMER);

    public void initialize() {

        btnDelete.setDisable(true);

        tblCustomers.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("id"));
        tblCustomers.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("name"));
        tblCustomers.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("address"));

        loadTable();

        tblCustomers.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<CustomerTM>() {
            @Override
            public void changed(ObservableValue<? extends CustomerTM> observable, CustomerTM oldValue, CustomerTM newValue) {
                btnDelete.setDisable(false);
                btnSave.setText("Update");

                CustomerTM selectedItem = tblCustomers.getSelectionModel().getSelectedItem();

                if (selectedItem == null) {
                    return;
                }

                txtID.setText(selectedItem.getId());
                txtName.setText(selectedItem.getName());
                txtAddress.setText(selectedItem.getAddress());

            }
        });
    }

    public void btnSaveOnAction(ActionEvent actionEvent) {

        String id = txtID.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();

        CustomerDTO customerDTO = new CustomerDTO(id, name, address);

        if (btnSave.getText().trim().equals("Save")) {
            save(customerDTO);
        } else {
            update(customerDTO);
        }

        txtID.clear();
        txtName.clear();
        txtAddress.clear();
        btnSave.setText("Save");
        loadTable();
    }

    public void btnDeleteOnAction(ActionEvent actionEvent) {
        String id = txtID.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();

        try {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Meyawa Delete Karanna onamada..?", ButtonType.YES, ButtonType.NO);
            Optional<ButtonType> buttonType = alert.showAndWait();

            if (buttonType.get().equals(ButtonType.YES)) {
                customerBO.deleteCustomer(new CustomerDTO(id, name, address));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void btnBackOnAction(ActionEvent actionEvent) {

    }

    public void loadTable() {
        ObservableList<CustomerTM> items = tblCustomers.getItems();
        items.clear();
        try {
            List<CustomerDTO> allCustomers = customerBO.getAllCustomers();
            for (CustomerDTO customer : allCustomers) {
                items.add(new CustomerTM(customer.getId(),
                        customer.getName(),
                        customer.getAddress()));
            }
            tblCustomers.refresh();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void save(CustomerDTO customerDTO) {
        try {
            boolean isAdded = customerBO.addCustomer(customerDTO);

            if (isAdded) {
                new Alert(Alert.AlertType.CONFIRMATION, "Wadea Goda...").showAndWait();
            } else {
                new Alert(Alert.AlertType.ERROR, "Wadea Aul Wagei").showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void update(CustomerDTO customerDTO) {
        try {
            boolean isAdded = customerBO.updateCustomer(customerDTO);

            if (isAdded) {
                new Alert(Alert.AlertType.CONFIRMATION, "Wadea Goda").showAndWait();
            } else {
                new Alert(Alert.AlertType.ERROR, "Wadea Aul Wage").showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
