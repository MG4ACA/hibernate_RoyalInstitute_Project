package lk.ijse.hibernate.business;

import lk.ijse.hibernate.business.custom.impl.CustomerBOImpl;
import lk.ijse.hibernate.business.custom.impl.ItemBOImpl;
import lk.ijse.hibernate.business.custom.impl.OrderBOImpl;
import lk.ijse.hibernate.business.custom.impl.OrderDetailBOImpl;
import lk.ijse.hibernate.dto.SuperDTO;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class BOFactory {
    private static BOFactory boFactory;


    private BOFactory(){

    }

    public static BOFactory getInstance(){
        return (boFactory == null) ? boFactory = new BOFactory() : boFactory;
    }

    public <T extends SuperBO> T getBO(BOType boType){
        switch (boType){
            case CUSTOMER:
                return (T) new CustomerBOImpl();
            case ITEM:
                return (T) new ItemBOImpl();
            case ORDER:
                return (T) new OrderBOImpl();
            case ORDER_DETAIL:
                return (T) new OrderDetailBOImpl();
            default:
                return null;
        }
    }
}
