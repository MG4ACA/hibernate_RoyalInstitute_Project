package lk.ijse.hibernate.business.custom.impl;

import lk.ijse.hibernate.business.custom.ItemBO;
import lk.ijse.hibernate.dao.DAOFactory;
import lk.ijse.hibernate.dao.DAOType;
import lk.ijse.hibernate.dao.SuperDAO;
import lk.ijse.hibernate.dao.custom.ItemDAO;
import lk.ijse.hibernate.dto.CustomerDTO;
import lk.ijse.hibernate.dto.ItemDTO;
import lk.ijse.hibernate.entity.Item;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class ItemBOImpl implements ItemBO {

    ItemDAO itemDAO = DAOFactory.getInstance().getDAO(DAOType.ITEM);

    @Override
    public boolean addItem(ItemDTO item) throws Exception {
        return itemDAO.add(new Item(item.getId(),
                item.getDescription(),
                item.getQty(),
                item.getUnitPrice()));
    }

    @Override
    public boolean deleteItem(ItemDTO item) throws Exception {
        return itemDAO.delete(new Item(item.getId(),
                item.getDescription(),
                item.getQty(),
                item.getUnitPrice()));
    }

    @Override
    public boolean updateItem(ItemDTO item) throws Exception {
        return itemDAO.update(new Item(item.getId(),
                item.getDescription(),
                item.getQty(),
                item.getUnitPrice()));
    }

    @Override
    public ItemDTO getItem(String id) throws Exception {
        Item one = itemDAO.getOne(id);

        return new ItemDTO(one.getId(),
                one.getDescription(),
                one.getQty(),
                one.getUnitPrice());
    }

    @Override
    public List<ItemDTO> getAllItems() throws Exception {

        List<Item> all = itemDAO.getAll();

        List<ItemDTO> itemDTOList = new ArrayList<>();

        for (Item item : all) {
            itemDTOList.add(new ItemDTO(item.getId(),
                    item.getDescription(),
                    item.getQty(),
                    item.getUnitPrice()));
        }
        return itemDTOList;
    }
}
