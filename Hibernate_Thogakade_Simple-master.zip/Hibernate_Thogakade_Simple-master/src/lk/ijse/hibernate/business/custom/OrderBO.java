package lk.ijse.hibernate.business.custom;

import lk.ijse.hibernate.business.SuperBO;
import lk.ijse.hibernate.dto.ItemDTO;
import lk.ijse.hibernate.dto.OrderDTO;

import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public interface OrderBO extends SuperBO {
    public boolean addOrder(OrderDTO orderDTO)throws Exception;

    public boolean deleteOrder(OrderDTO orderDTO)throws Exception;

    public boolean updateOrder(OrderDTO orderDTO)throws Exception;

    public OrderDTO getOrder(String id)throws Exception;

    public List<OrderDTO> getAllOrders()throws Exception;
}
