package lk.ijse.hibernate.business.custom;

import lk.ijse.hibernate.business.SuperBO;
import lk.ijse.hibernate.dto.CustomerDTO;

import java.util.*;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public interface CustomerBO extends SuperBO {
    public boolean addCustomer(CustomerDTO customer)throws Exception;

    public boolean deleteCustomer(CustomerDTO customer)throws Exception;

    public boolean updateCustomer(CustomerDTO customer)throws Exception;

    public CustomerDTO getCustomer(String id)throws Exception;

    public List<CustomerDTO> getAllCustomers()throws Exception;
}
