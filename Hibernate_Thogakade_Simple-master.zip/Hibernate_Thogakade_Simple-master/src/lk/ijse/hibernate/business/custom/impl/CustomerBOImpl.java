package lk.ijse.hibernate.business.custom.impl;

import lk.ijse.hibernate.business.custom.CustomerBO;
import lk.ijse.hibernate.dao.DAOFactory;
import lk.ijse.hibernate.dao.DAOType;
import lk.ijse.hibernate.dao.custom.CustomerDAO;
import lk.ijse.hibernate.dto.CustomerDTO;
import lk.ijse.hibernate.entity.Customer;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class CustomerBOImpl implements CustomerBO {

    CustomerDAO customerDAO = DAOFactory.getInstance().getDAO(DAOType.CUSTOMER);

    @Override
    public boolean addCustomer(CustomerDTO customer) throws Exception {
        return customerDAO.add(new Customer(customer.getId(),
                customer.getName(),
                customer.getAddress()));
    }

    @Override
    public boolean deleteCustomer(CustomerDTO customer) throws Exception {
       return customerDAO.delete(new Customer(customer.getId(),
                customer.getName(),
                customer.getAddress()));
    }

    @Override
    public boolean updateCustomer(CustomerDTO customer) throws Exception {
        return customerDAO.update(new Customer(customer.getId(),
                customer.getName(),
                customer.getAddress()));
    }

    @Override
    public CustomerDTO getCustomer(String id) throws Exception {
        Customer c = customerDAO.getOne(id);

        return new CustomerDTO(c.getId(),
                c.getName(),
                c.getAddress());
    }

    @Override
    public List<CustomerDTO> getAllCustomers() throws Exception {
        List<Customer> customerList = customerDAO.getAll();

        List<CustomerDTO> customerDTOList = new ArrayList<>();

        for (Customer customer : customerList) {
            customerDTOList.add(new CustomerDTO(customer.getId(),
                    customer.getName(),
                    customer.getAddress()));
        }
        return customerDTOList;
    }
}
