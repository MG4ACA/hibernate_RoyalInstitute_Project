package lk.ijse.hibernate.business.custom;

import lk.ijse.hibernate.dto.CustomerDTO;
import lk.ijse.hibernate.dto.ItemDTO;

import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public interface ItemBO {
    public boolean addItem(ItemDTO item)throws Exception;

    public boolean deleteItem(ItemDTO item)throws Exception;

    public boolean updateItem(ItemDTO item)throws Exception;

    public ItemDTO getItem(String id)throws Exception;

    public List<ItemDTO> getAllItems()throws Exception;
}
