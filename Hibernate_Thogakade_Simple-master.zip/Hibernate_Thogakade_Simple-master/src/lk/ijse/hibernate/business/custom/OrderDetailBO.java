package lk.ijse.hibernate.business.custom;

import lk.ijse.hibernate.dto.OrderDTO;
import lk.ijse.hibernate.dto.OrderDetailsDTO;

import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public interface OrderDetailBO {
    public boolean addOrder(OrderDetailsDTO orderDetailsDTO)throws Exception;

    public OrderDetailsDTO getOrder(String id)throws Exception;

    public List<OrderDetailsDTO> getAllOrders()throws Exception;
}
