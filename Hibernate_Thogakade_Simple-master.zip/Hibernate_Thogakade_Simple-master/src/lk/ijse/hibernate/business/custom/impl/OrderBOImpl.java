package lk.ijse.hibernate.business.custom.impl;

import lk.ijse.hibernate.business.custom.OrderBO;
import lk.ijse.hibernate.dao.DAOFactory;
import lk.ijse.hibernate.dao.DAOType;
import lk.ijse.hibernate.dao.custom.OrderDAO;
import lk.ijse.hibernate.dto.OrderDTO;
import lk.ijse.hibernate.entity.Order;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class OrderBOImpl implements OrderBO {

    OrderDAO orderDAO = DAOFactory.getInstance().getDAO(DAOType.ORDER);

    @Override
    public boolean addOrder(OrderDTO orderDTO) throws Exception {
        return orderDAO.add(new Order(orderDTO.getId(),
                orderDTO.getDate(),
                orderDTO.getTotal(),
                orderDTO.getCustomer()));
    }

    @Override
    public boolean deleteOrder(OrderDTO orderDTO) throws Exception {
        return orderDAO.delete(new Order(orderDTO.getId(),
                orderDTO.getDate(),
                orderDTO.getTotal(),
                orderDTO.getCustomer()));
    }

    @Override
    public boolean updateOrder(OrderDTO orderDTO) throws Exception {
        return orderDAO.update(new Order(orderDTO.getId(),
                orderDTO.getDate(),
                orderDTO.getTotal(),
                orderDTO.getCustomer()));
    }

    @Override
    public OrderDTO getOrder(String id) throws Exception {
        Order o = orderDAO.getOne(id);

        return new OrderDTO(o.getId(),o.getDate(),o.getTotal(),o.getCustomer());
    }

    @Override
    public List<OrderDTO> getAllOrders() throws Exception {
        List<Order> all = orderDAO.getAll();

        List<OrderDTO> orderDTOS = new ArrayList<>();
        for (Order order : all) {
            orderDTOS.add(new OrderDTO(order.getId(),
                    order.getDate(),
                    order.getTotal(),
                    order.getCustomer()));
        }
        return orderDTOS;
    }
}
