package lk.ijse.hibernate.business.custom.impl;

import lk.ijse.hibernate.business.custom.OrderDetailBO;
import lk.ijse.hibernate.dao.DAOFactory;
import lk.ijse.hibernate.dao.DAOType;
import lk.ijse.hibernate.dao.custom.OrderDetailDAO;
import lk.ijse.hibernate.dto.OrderDetailsDTO;
import lk.ijse.hibernate.entity.OrderDetail;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class OrderDetailBOImpl implements OrderDetailBO {

    OrderDetailDAO orderDetailDAO = DAOFactory.getInstance().getDAO(DAOType.ORDER_DETAIL);

    @Override
    public boolean addOrder(OrderDetailsDTO orderDetailsDTO) throws Exception {
        return orderDetailDAO.add(new OrderDetail(orderDetailsDTO.getId(),
                orderDetailsDTO.getItemCode(),
                orderDetailsDTO.getItemQty(),
                orderDetailsDTO.getOrder()));
    }

    @Override
    public OrderDetailsDTO getOrder(String id) throws Exception {
        OrderDetail one = orderDetailDAO.getOne(id);

        return new OrderDetailsDTO(one.getId(),
                one.getItemCode(),
                one.getQty(),
                one.getOrder());
    }

    @Override
    public List<OrderDetailsDTO> getAllOrders() throws Exception {
        List<OrderDetail> all = orderDetailDAO.getAll();

        List<OrderDetailsDTO> list = new ArrayList<>();

        for (OrderDetail orderDetail : all) {
            list.add(new OrderDetailsDTO(orderDetail.getId(),
                    orderDetail.getItemCode(),
                    orderDetail.getQty(),
                    orderDetail.getOrder()));
        }

        return list;
    }
}
