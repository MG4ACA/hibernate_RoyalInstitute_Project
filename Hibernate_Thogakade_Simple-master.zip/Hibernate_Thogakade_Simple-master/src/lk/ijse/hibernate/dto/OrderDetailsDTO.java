package lk.ijse.hibernate.dto;

import lk.ijse.hibernate.entity.Item;
import lk.ijse.hibernate.entity.Order;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class OrderDetailsDTO implements SuperDTO{
    private String id;
    private Item itemCode;
    private Item itemQty;
    private Order order;

    public OrderDetailsDTO(String id, Item itemCode, Item itemQty, Order order) {
        this.id = id;
        this.itemCode = itemCode;
        this.itemQty = itemQty;
        this.order = order;
    }

    public OrderDetailsDTO() {
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Item getItemCode() {
        return itemCode;
    }

    public void setItemCode(Item itemCode) {
        this.itemCode = itemCode;
    }

    public Item getItemQty() {
        return itemQty;
    }

    public void setItemQty(Item itemQty) {
        this.itemQty = itemQty;
    }

    @Override
    public String toString() {
        return "OrderDetailsDTO{" +
                "id='" + id + '\'' +
                ", itemCode=" + itemCode +
                ", itemQty=" + itemQty +
                '}';
    }
}
