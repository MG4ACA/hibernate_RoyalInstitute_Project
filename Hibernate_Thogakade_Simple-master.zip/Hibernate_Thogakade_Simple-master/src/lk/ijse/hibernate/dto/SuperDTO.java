package lk.ijse.hibernate.dto;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public interface SuperDTO {
}
