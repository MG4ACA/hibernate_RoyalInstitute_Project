package lk.ijse.hibernate.dto;

import lk.ijse.hibernate.entity.Customer;

/**
 * @author : K.S.P.D De Silva <sanodeemantha@gmail.com>
 * @since : 1/25/21
 **/

public class OrderDTO implements SuperDTO{
    private String id;
    private String date;
    private String total;
    private Customer customer;

    public OrderDTO(String id, String date, String total, Customer customer) {
        this.id = id;
        this.date = date;
        this.total = total;
        this.customer = customer;
    }


    public OrderDTO() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "OrderDTO{" +
                "id='" + id + '\'' +
                ", date='" + date + '\'' +
                ", total='" + total + '\'' +
                ", customer=" + customer +
                '}';
    }
}
