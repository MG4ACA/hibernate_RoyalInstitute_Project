package model;

import entity.Course;
import entity.Student;

public class HqlTM {
    private Object code;
    private Object regI;
    private Object id;
    private Object name;

    public HqlTM() {
    }

    public HqlTM(Object code, Object regI, Object id, Object name) {
        this.code = code;
        this.regI = regI;
        this.id = id;
        this.name = name;
    }

    public Object getCode() {
        return code;
    }

    public void setCode(Object code) {
        this.code = code;
    }

    public Object getRegI() {
        return regI;
    }

    public void setRegI(Object regI) {
        this.regI = regI;
    }

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public Object getName() {
        return name;
    }

    public void setName(Object name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "HqlTM{" +
                "code=" + code +
                ", regI=" + regI +
                ", id=" + id +
                ", name=" + name +
                '}';
    }
}
