package dto;

public interface SuperDTO {
}
