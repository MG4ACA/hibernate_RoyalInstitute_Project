package dao;

public enum DAOType {
    STUDENT,COURSE,REGISTRATION,USER;
}
