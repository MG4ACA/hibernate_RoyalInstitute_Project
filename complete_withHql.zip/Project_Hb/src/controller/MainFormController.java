package controller;

import dto.RegistrationDTO;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.HqlTM;
import model.RegistrationTM;
import org.hibernate.Session;
import org.hibernate.query.Query;
import util.FactoryConfiguration;

import java.io.IOException;
import java.util.List;

public class MainFormController {
    public Button btnRegistration;
    public Button btnStudent;
    public Button btnCourse;
    public Button btnUserManage;
    public AnchorPane subAnchorPane;
    public Button btnLogOff;
    public AnchorPane anchorPane;
    public TableColumn clmCourseCode;
    public TableColumn clmRegId;
    public TableColumn clmStudentId;
    public TableColumn clmStudentName;
    public TableView tblHql;

    public void initialize() {
        clmCourseCode.setCellValueFactory(new PropertyValueFactory<> ("code"));
        clmRegId.setCellValueFactory (new PropertyValueFactory<> ("regI"));
        clmStudentId.setCellValueFactory(new PropertyValueFactory<> ("id"));
        clmStudentName.setCellValueFactory(new PropertyValueFactory<> ("name"));
        loadTable();
    }
    public void loadTable() {
        ObservableList<HqlTM> items = tblHql.getItems();
        items.clear();
            Session session = FactoryConfiguration.getInstance ().getSession ();
            Query from_Hql = session.createQuery ("select registration.course.code, registration.regNo,student.id, student.studentName\n" +
                    "from Student student\n" +
                    "inner join Registration registration on student.id=registration.student.id");
            List<Object[]> list = from_Hql.list ();
            for ( Object[] hql : list ) {
                items.add (new HqlTM (hql[0], hql[1], hql[2], hql[3]));
            }
    }
    /**
     * @param location
     * load fxml files to the subAnchorPane of the MainForm.fxml
     * @throws IOException
     */
    public void setSubAnchorPane ( String location ) throws IOException {
        this.subAnchorPane.getChildren().clear();
        this.subAnchorPane.getChildren().add(FXMLLoader.load(this.getClass().getResource("../view/"+location)));
    }
    /**
     * @param location
     * load fxml file in new {@link Scene}
     * @throws IOException
     */
    public void setAnchorPane(String location) throws IOException {
        Stage stage = (Stage) anchorPane.getScene().getWindow();
        stage.setScene(new Scene(FXMLLoader.load(this.getClass().getResource("/view/" + location))));
    }
    public void registerOnAction(ActionEvent actionEvent) throws IOException {
        setSubAnchorPane("registrationForm.fxml");
    }

    public void studentOnAction(ActionEvent actionEvent) throws IOException {
        setSubAnchorPane("studentForm.fxml");
    }

    public void courseOnAction(ActionEvent actionEvent) throws IOException {
        setSubAnchorPane("courseForm.fxml");
    }

    public void userManageOnAction(ActionEvent actionEvent) throws IOException {
        setSubAnchorPane("userManageForm.fxml");
    }

    public void logOffOnAction(ActionEvent actionEvent) throws IOException {
        setAnchorPane("loginForm.fxml");
    }

    public void mainOnAction(ActionEvent actionEvent) throws IOException {
        setAnchorPane ("mainForm.fxml");
    }
}
