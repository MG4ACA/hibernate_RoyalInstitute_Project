package controller;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginFormController {
    public JFXPasswordField txtPassword;
    public JFXTextField txtUserName;
    public JFXTextField txtPw;
    public Button btnCancel;
    public Button btnLogin;
    public AnchorPane anchorPane;
    public static String fuckedUpId;
    public static String fuckedUpPw;
    public static int fuck;
    public static String[][] Users = new String[][]{{"User1", "12345"}, {"User2", "00000"}, {"User3", "11111"}, {"User4", "22222"}};

    public void pwImgOnAction(MouseEvent mouseEvent) {
        txtPassword.setVisible (false);
        txtPw.setVisible (true);
        txtPw.setText (txtPassword.getText ());
    }

    public void CancelOnAction(ActionEvent actionEvent) {
        txtUserName.clear ();
        txtPassword.clear ();
    }

    public void loginOnAction(ActionEvent actionEvent) {
        boolean t=true;
        for ( int i = 0; i < 4; i++ ) {
            if (Users[i][0].equals (txtUserName.getText ()) && Users[i][1].equals (txtPassword.getText ())) {
                Stage stage = (Stage) anchorPane.getScene ().getWindow ();
                try{
                    stage.setScene (new Scene (FXMLLoader.load (this.getClass ().getResource ("/view/mainForm.fxml"))));
                    stage.setTitle ("Main Form");
                }catch(IOException e){
                    e.printStackTrace ();
                }
                fuckedUpId=txtUserName.getText ();
                fuckedUpPw=txtPassword.getText ();
                fuck=i;
                t = false;
                break;
            }
        }
        if(t){
            Alert alert = new Alert (Alert.AlertType.WARNING, "Wrong Login Details");
            alert.show ();
        }
    }
}
