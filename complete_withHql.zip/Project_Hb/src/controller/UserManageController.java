package controller;

import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import static controller.LoginFormController.*;

public class UserManageController {
    public JFXTextField txtUserName;
    public Label lblPassword;
    public Label lblUserName;
    public JFXTextField txtPassword;
    public Button btnUpdate;

    public void initialize() {
        lblUserName.setText(fuckedUpId);
        lblPassword.setText(fuckedUpPw);

    }
    public void updateOnAction(ActionEvent actionEvent) {
        Users[fuck][0]=txtUserName.getText ();
        Users[fuck][1]=txtPassword.getText();
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "User Updated");
        alert.show();
        loadLables ();
    }
    public void loadLables(){
        lblUserName.setText(Users[fuck][0]);
        lblPassword.setText(Users[fuck][1]);
    }
    private void clear() {
        txtUserName.clear();
        txtPassword.clear();
    }
}
