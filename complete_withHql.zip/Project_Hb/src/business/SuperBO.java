package business;

public interface SuperBO {
}
