/*
package business.custom;

import business.SuperBO;
import dto.StudentDTO;
import dto.UserDTO;

import java.util.List;

public interface UserBO extends SuperBO {
    public boolean updateUser(UserDTO user)throws Exception;

    public UserDTO getUser(String id)throws Exception;

    public List<UserDTO> getAllUsers()throws Exception;
}
*/
